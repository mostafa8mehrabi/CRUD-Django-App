#part 1
#from django.shortcuts import render
#from django.http import HttpResponse
##Create your views here.
#def index(request):
#    return HttpResponse("Hello world!")
# #Part 2 
# #from django.http import HttpResponse
# #from django.template import loader
# #
# #def index(request):
# #  template = loader.get_template('myfirst.html')
# #  return HttpResponse(template.render())
## part 3
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.urls import reverse
from .models import Members

def index(request):
  mymembers = Members.objects.all().values()
  template = loader.get_template('index.html')
  context = {
    'mymembers': mymembers,
  }
  return HttpResponse(template.render(context, request))
def add(request):
  template = loader.get_template('add.html')
  return HttpResponse(template.render({}, request))
###
def addrecord(request):
  firstName = request.POST['first']
  lastName = request.POST['last']
  Address = request.POST['Address']
  national_id = request.POST['national_id']
  mobilePhone = request.POST['mobilePhone']
  balance = request.POST['balance']
  member = Members(firstname=firstName, lastname=lastName,Address=Address,national_id=national_id,mobilePhone=mobilePhone,balance=balance)
  member.save()
  return HttpResponseRedirect(reverse('index'))
def delete(request, id):
  member = Members.objects.get(id=id)
  member.delete()
  return HttpResponseRedirect(reverse('index'))

def update(request, id):
  mymember = Members.objects.get(id=id)
  template = loader.get_template('update.html')
  context = {
    'mymember': mymember,
  }
  return HttpResponse(template.render(context, request))
def mojodi(request, id):
  mymember = Members.objects.get(id=id)
  template = loader.get_template('mojodi.html')
  context = {
    'mymember': mymember,
  }
  return HttpResponse(template.render(context, request))
  ##
def updaterecord(request, id):
  first = request.POST['first']
  last = request.POST['last']
  Address = request.POST['Address']
  national_id = request.POST['national_id']
  mobilePhone = request.POST['mobilePhone']
  balance = request.POST['balance']
  member = Members.objects.get(id=id)
  member.firstname = first
  member.lastname = last
  member.Address=Address
  member.national_id=national_id
  member.mobilePhone=mobilePhone
  member.balance=balance
  member.save()
  return HttpResponseRedirect(reverse('index'))

#
def updatemojodi(request, id):
  balance = request.POST['balance']
  member = Members.objects.get(id=id)
  member.balance = balance
  member.save()
  return HttpResponseRedirect(reverse('index'))